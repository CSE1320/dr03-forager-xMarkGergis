import Message from "../../components/Message";

export default function SandboxPage() {
    return (
      <div className="page flex justify-center items-center flex-row">
        <Message/>
      </div>
    );
}
  