import NavBar from '../../components/NavBar';

export default function PhotoSearchPage() {
  return (
    <div className="page">
      <h1>Photo Search Page</h1>
      <NavBar />
    </div>
  );
}
